social.tinywall.com
===================

Tinywall Social Networking

###Installation Instruction

* Create a database 'tinywall_db' and run SQL the file https://github.com/tinywall/social/blob/master/tinywall_db.sql

* Configure the encription key in https://github.com/tinywall/social/blob/master/application/config/config.php and database details in https://github.com/tinywall/social/blob/master/application/config/database.php

* Go to http://localhost/social/ and login with username: demouser ; password: demouser
