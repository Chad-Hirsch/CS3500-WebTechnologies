<?php

	$config['tweet_consumer_key'] = "";
	$config['tweet_consumer_secret'] = "";
