<?php
 
$lang['lang.gender'] = "I'm a man";
$lang['lang.name'] = "My name is %s.I am %s";
$lang['lang.dashboardtitle'] = "Dashboard(english) of %s";