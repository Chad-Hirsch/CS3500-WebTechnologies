<?php
$lang['lang.gender'] = "e suis un homme";
$lang['lang.name'] = "%s is my name and %s is me.";
$lang['lang.dashboardtitle'] = "%s's என் பெயர் என் பெயர்dashboard(french)";