</div>
</div>
</div>
</div>
<div id="tw-footer">
	<div id="tw-footer-outer">
		<div id="tw-footer-links">
			<a href="<?php echo base_url().'landing/about';?>">about</a> | 
			<a href="<?php echo base_url().'landing/developers';?>">developers</a> | 
			<a href="<?php echo base_url().'landing/tour';?>">tour</a> | 
			<a href="<?php echo base_url().'landing/api';?>">api</a> | 
			<a href="<?php echo base_url().'landing/terms';?>">terms & conditions</a>
		</div>
		<div id="tw-footer-copy"> Copyright &copy; 2011 | TinyWall.</div>
		<div class="clear"></div>
	</div>
</div>
</body>
</html>