 <script language="javascript" type="text/javascript" src="<?php echo base_url();?>js/jqplot.barRenderer.min.js"></script>
 <script language="javascript" type="text/javascript" src="<?php echo base_url();?>js/jqplot.categoryAxisRenderer.min.js"></script>
 <script type="text/javascript" language="javascript">
 $(document).ready(function(){
      $.jqplot.config.enablePlugins = true;
         line1 = [
			<?php
			$first=1;$rtoplogin=array_reverse($toplogin);
			foreach($rtoplogin as $row){
			if(!$first){echo ",";}
				$first=0;
				echo "[".$row->total_login.",'<b>".$row->username."</b><br/>".$row->total_login." logins']";
			}
			?>
		 ];
         plot1 = $.jqplot('chart', [line1], {
            title:'Top Logged In Users',
             seriesDefaults:{
               renderer:$.jqplot.BarRenderer, 
               rendererOptions:{
                 barWidth:25, 
                 barPadding:-25, 
                 barMargin:25, 
                 barDirection: 'horizontal',
                 varyBarColor: true
               }, 
               shadow:false
             },
             legend: {show:false},
             axes:{
                 xaxis:{
				 label: 'No of Logins',
            min:0, tickOptions: {formatString: '%.0f',showGridLine: false}},
                 yaxis:{show: true, renderer: $.jqplot.CategoryAxisRenderer,
                            tickOptions: {show: true, showLabel: true},
                            showTicks: true}
                 }
         });
	});
		 
 </script>
 Highest Logins
 <div id="chart" style="width:700px;height:450px;margin:20px;"></div> 
 
<?php
$no=1;
foreach($toplogin as $user){
	echo ($no++).' ) <a href="'.base_url().$user->username.'">'.$user->first_name." ".$user->last_name."</a><br/>";
	
} 


?>
