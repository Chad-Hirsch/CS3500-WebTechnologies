</div>
<div class="clear"></<div>
</div>
</div>
</div>
<div id="tw-footer">
	<div id="tw-footer-outer">
		<div id="tw-footer-copy"> Copyright &copy; 2011 | TinyWall.</div>
	</div>
</div>
</body>
</html>