<a href="<?php echo base_url();?>setting/account">Account</a> | 
<a href="<?php echo base_url();?>setting/password">Password</a> | 
<a href="<?php echo base_url();?>setting/themes">Themes</a> | 
<a href="<?php echo base_url();?>setting/privacy">Privacy</a>
<br><hr/><br>