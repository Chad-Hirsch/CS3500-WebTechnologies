<h1><?php echo lang('lang.dashboardtitle','',$session_user->first_name." ".$session_user->last_name);?></h1>
<div id="tw-page-main-content">content</div>
