<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php if(isset($page_title)){echo $page_title;}else{echo "TinyWall";}?></title>
<script language="javascript" src="<?php echo base_url();?>js/jquery-1.4.4.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/jquery.validity.js"></script>
<link type="text/css" rel="Stylesheet" href="<?php echo base_url();?>css/jquery.validity.css" />
<script language="javascript" src="<?php echo base_url();?>js/script.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/themes/default.css" />
</head>
<body>
<div id="tw-container">
<div id="tw-header">
	<div id="tw-header-outer">
		<a href="<?php echo base_url();?>"><img id="tw-logo" src='<?php echo base_url();?>images/themes/default/logo.png'/></a>
	</div>
</div>
<div id="tw-content">
<div id="tw-content-outer">&nbsp;
<div id="tw-public-content-outer">
