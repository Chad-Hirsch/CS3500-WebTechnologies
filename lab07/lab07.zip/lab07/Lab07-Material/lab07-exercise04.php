<html>
<head>
<title>Lab 07 - Exercise 4</title>
</head>
<body>
<h1>Age calculator</h1>

<ul>
   <li><?php  ?> seconds, or </li>
   <li><?php  ?> days, or </li>
   <li><?php  ?> months, or </li>
   <li><?php  ?> years</li>
</ul>
</body>
</html>
