<html>
<head>
<title>Lab 07 - Exercise 7</title>
</head>
<body>
<h1>Simple Calendar using Loops</h1>

<table border="1">

<tr>
  <th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th>
</tr>
<?php 

?>

</table>


</body>
</html>
